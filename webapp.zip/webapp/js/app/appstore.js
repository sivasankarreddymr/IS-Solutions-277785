(function(){
	var app = angular.module("ARTSApp");
	app.factory('appstore',[function(){
		var app = {};
		return{
			storeData: function(param, data){
				app[param] = data;
			},
			getData: function(param){
				return app[param];
			}
		};
	}]);
})();