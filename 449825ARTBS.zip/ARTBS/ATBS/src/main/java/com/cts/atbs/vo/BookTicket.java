package com.cts.atbs.vo;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="bookings")
public class BookTicket {
	
	private int bookingId;
	private String email;
	private String airline;
	private String deptdate;
	private String arrivaltime;	
	private int noOfPassengers;	
	private String bookingStatus;
	
	
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public String getBookingStatus() {
		return bookingStatus;
	}
	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}

	
	private int totPrice;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public String getDeptdate() {
		return deptdate;
	}
	public void setDeptdate(String deptdate) {
		this.deptdate = deptdate;
	}
	public String getArrivaltime() {
		return arrivaltime;
	}
	public void setArrivaltime(String arrivaltime) {
		this.arrivaltime = arrivaltime;
	}
	public int getNoOfPassengers() {
		return noOfPassengers;
	}
	public void setNoOfPassengers(int noOfPassengers) {
		this.noOfPassengers = noOfPassengers;
	}
	public int getTotPrice() {
		return totPrice;
	}
	public void setTotPrice(int totPrice) {
		this.totPrice = totPrice;
	}
	
	
}
