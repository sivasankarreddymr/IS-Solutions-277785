package com.cts.atbs.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.atbs.exception.AtbsException;
import com.cts.atbs.repo.AtbsRepository;
import com.cts.atbs.vo.AirLineTicket;
import com.cts.atbs.vo.AirLineTicketVo;
import com.cts.atbs.vo.BookTicket;
import com.cts.atbs.vo.Customer;

@Service
public class AtbsServiceImpl implements AtbsService {
	
	@Autowired
	 AtbsRepository repo;
	
	@Override
	public boolean register(Customer customer) throws AtbsException {
		return repo.register(customer);
	}

	@Override
	public boolean login(Customer customer) throws AtbsException {
		return repo.login(customer);
	}

	@Override
	public List<AirLineTicketVo> searchFlights(AirLineTicketVo ticket) throws AtbsException {
		
		List<AirLineTicket> list= repo.searchFlights(ticket);
		
		 List<AirLineTicketVo> listVo=new ArrayList<>();
		
		for (AirLineTicket airlineTicket : list) {			
			
			AirLineTicketVo airLineTicketVo=new AirLineTicketVo();
			
			airLineTicketVo.setAirline(airlineTicket.getAirline());
			airLineTicketVo.setDeptdate(airlineTicket.getDeptdate());
			airLineTicketVo.setDepttime(airlineTicket.getDepttime());
			airLineTicketVo.setArrivaltime(airlineTicket.getArrivaltime());			
			airLineTicketVo.setPrice(airlineTicket.getPrice());
			airLineTicketVo.setNoOfPassengers(ticket.getNoOfPassengers());
			airLineTicketVo.setTotPrice(ticket.getNoOfPassengers()*airlineTicket.getPrice());
			listVo.add(airLineTicketVo);
		}
		
		return listVo;
	}

	@Override
	public boolean bookFlight(BookTicket ticket) throws AtbsException {
		ticket.setBookingStatus("Y");
		ticket.setBookingId(getBookingId());
		return repo.bookFlight(ticket);
	}

	private int getBookingId() throws AtbsException {
		return (int)(Math.round(Math.random()*4));
	}

	@Override
	public boolean cancelTicket(BookTicket ticket)throws AtbsException {
		ticket.setBookingStatus("N");
		return repo.cancelTicket(ticket);
	}

	@Override
	public List<BookTicket> getFlights(BookTicket ticket) throws AtbsException {
		return repo.getFlights(ticket);
	}

}
