package com.cts.atbs.service;

import java.util.List;

import com.cts.atbs.exception.AtbsException;
import com.cts.atbs.vo.AirLineTicketVo;
import com.cts.atbs.vo.BookTicket;
import com.cts.atbs.vo.Customer;

public interface AtbsService {
	
	boolean register(Customer cust)throws AtbsException ;

	boolean login(Customer cust)throws AtbsException ;

	List<AirLineTicketVo> searchFlights(AirLineTicketVo ticket)throws AtbsException ;

	boolean bookFlight(BookTicket ticket)throws AtbsException ;

	boolean cancelTicket(BookTicket ticket) throws AtbsException ;

	List<BookTicket> getFlights(BookTicket ticket) throws AtbsException ;

}
