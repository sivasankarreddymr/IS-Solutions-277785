package com.cts.atbs.exception;

public class AtbsException extends Exception {
	
	public AtbsException(String str) {
		super(str);
	}

}
