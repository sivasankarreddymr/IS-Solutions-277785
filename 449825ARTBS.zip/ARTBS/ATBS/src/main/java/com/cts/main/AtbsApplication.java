package com.cts.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages= {"com.cts.atbs.controller","com.cts.atbs.service","com.cts.atbs.repo","com.cts.atbs.vo"})
public class AtbsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtbsApplication.class, args);
	}
}
