package com.cts.atbs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.cts.atbs.exception.AtbsException;
import com.cts.atbs.service.AtbsService;
import com.cts.atbs.vo.AirLineTicketVo;
import com.cts.atbs.vo.BookTicket;
import com.cts.atbs.vo.Customer;
import com.cts.atbs.vo.Response;

@Controller
@CrossOrigin("*")
public class AtbsController {
	
	@Autowired
	AtbsService service;
	
	@RequestMapping("/")
	public String getHome() {
		return "index";
	}
	
	@RequestMapping(value="/register",method=RequestMethod.POST,produces="application/json")
	@ResponseBody
	public Response register(@RequestBody Customer customer) {		
		boolean flag;
		Response response=new Response();	
		try {
			flag = service.register(customer);			
			if(flag) {
				response.setFlag(false);
				response.setData("User Already Registered");
			}else {
				response.setFlag(true);
				response.setData("User Succesfully Registered");
			}
		} catch (AtbsException e) {
			response.setFlag(false);
			response.setData(e.getMessage());
		}
				 
		return response;
	}
	
	@RequestMapping(value="/validateLogin",method=RequestMethod.POST,produces="application/json")
	@ResponseBody
	public Response login(@RequestBody Customer customer) {		
		boolean flag;
		Response response=new Response();
		try {
			flag = service.login(customer);
			response.setFlag(flag);
			if(flag) {
				response.setData(customer.getEmail());
			}else {
				response.setData("Authentication Failed");
			}
		} catch (AtbsException e) {
			response.setFlag(false);
			response.setData(e.getMessage());
		}		
		
		return response;
	}

	
	@RequestMapping(value="/searchFlights",method=RequestMethod.POST,produces="application/json")
	@ResponseBody
	public Response searchFlights(@RequestBody AirLineTicketVo ticket) {	
		
		List<AirLineTicketVo> ticketList;
		Response response=new Response();
		try {
			ticketList = service.searchFlights(ticket);
			response.setFlag(true);
			response.setData(ticketList);
		} catch (AtbsException e) {
			response.setFlag(false);
			response.setData(e.getMessage());
		}	
		return response;
	}
	
	@RequestMapping(value="/bookFlight",method=RequestMethod.POST,produces="application/json")
	@ResponseBody
	public Response bookFlight(@RequestBody BookTicket ticket) {		
		boolean flag;
		Response response=new Response();
		try {
			flag = service.bookFlight(ticket);
			response.setFlag(flag);
			if(flag) {			
				response.setData("Ticket Booked Succesfully");
			}else {
				response.setData("Error while booking ticket");
			}	
		} catch (AtbsException e) {
			response.setFlag(false);
			response.setData(e.getMessage());
		} 
		return response;
	}
	
	@RequestMapping(value="/getFlights",method=RequestMethod.POST,produces="application/json")
	@ResponseBody
	public Response getFlights(@RequestBody BookTicket ticket) {		
		List<BookTicket> ticketList;
		Response response=new Response();
		try {
			ticketList = service.getFlights(ticket);
			response.setFlag(true);
			response.setData(ticketList);
		} catch (AtbsException e) {
			response.setFlag(false);
			response.setData(e.getMessage());
		} 
		
		return response;
	}
	
	@RequestMapping(value="/cancelTicket",method=RequestMethod.POST,produces="application/json")
	@ResponseBody
	public Response cancelTicket(@RequestBody BookTicket ticket) {		
		boolean flag;
		Response response=new Response();
		try {
			flag = service.cancelTicket(ticket);
			response.setFlag(flag);
			if(flag) {			
				response.setData("Ticket Cancelled Succesfully");
			}else {
				response.setData("Error while cancel ticket");
			}		
		} catch (AtbsException e) {
			response.setFlag(false);
			response.setData(e.getMessage());
		} 
		return response;
	}
}


