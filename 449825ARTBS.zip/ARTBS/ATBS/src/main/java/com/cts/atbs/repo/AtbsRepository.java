package com.cts.atbs.repo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.cts.atbs.exception.AtbsException;
import com.cts.atbs.vo.AirLineTicket;
import com.cts.atbs.vo.AirLineTicketVo;
import com.cts.atbs.vo.BookTicket;
import com.cts.atbs.vo.Customer;

@Repository
public class AtbsRepository {
	
	@Autowired
	MongoTemplate template;
	
	public boolean register(Customer customer) throws AtbsException {
		boolean flag=false;
		try {
			Query query=new Query();
			query.addCriteria(Criteria.where("email").is(customer.getEmail()));	
			flag= template.exists(query,Customer.class);
			if(flag) {
				return flag;
			}else {
				template.save(customer);
			}
		}catch (Exception e) {
			throw new AtbsException("Exception while register");
		}
		return flag;
	}

	public boolean login(Customer customer) throws AtbsException {
		boolean flag=false;
		try {
			Query query=new Query();
			query.addCriteria(Criteria.where("email").is(customer.getEmail()).and("password").is(customer.getPassword()));	
			flag= template.exists(query,Customer.class);
		}catch (Exception e) {
			throw new AtbsException("Exception while login");
		}
		return flag;
		
	}

	public List<AirLineTicket> searchFlights(AirLineTicketVo ticket) throws AtbsException {
		List<AirLineTicket> list;
		try {
			Query query=new Query();
			query.addCriteria(Criteria.where("source").is(ticket.getSource()).and("destination").is(ticket.getDestination())
					.and("category").is(ticket.getCategory()).and("deptdate").is(ticket.getDeptdate()).and("depttime").is(ticket.getDepttime()));	
			list= template.find(query,AirLineTicket.class);
		}catch (Exception e) {
			throw new AtbsException("Exception while searchFlights");
		}
		return list;
	}

	public boolean bookFlight(BookTicket ticket) throws AtbsException {		
		try {
			template.save(ticket);
		}catch (Exception e) {
			throw new AtbsException("Exception while bookFlight");
		}
		return true;
	}

	public boolean cancelTicket(BookTicket ticket) throws AtbsException {
		try {
			Query query=new Query();
			query.addCriteria(Criteria.where("bookingId").is(ticket.getBookingId()));		
			Update update=new Update();
			update.set("bookingStatus", ticket.getBookingStatus());		
			template.updateFirst(query, update, BookTicket.class);
		}catch (Exception e) {
			throw new AtbsException("Exception while cancelTicket");
		}
		return true;
	}

	public List<BookTicket> getFlights(BookTicket ticket) throws AtbsException {	
		List<BookTicket> list;
		try {
			
			Query query=new Query();
			query.addCriteria(Criteria.where("email").is(ticket.getEmail()).and("bookingStatus").is("Y"));			
			list= template.find(query, BookTicket.class);
		}catch (Exception e) {
			throw new AtbsException("Exception in getFlights");
		}
		return list;
	}

}
