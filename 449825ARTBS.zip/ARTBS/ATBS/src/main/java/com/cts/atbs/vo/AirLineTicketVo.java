package com.cts.atbs.vo;

public class AirLineTicketVo {
	
	private String airline;
	private String source;
	private String destination;
	private String category;
	private int price;
	private String deptdate;
	private String depttime;
	private String arrivaltime;	
	private int noOfPassengers;
	private int totPrice;
	
	
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getDeptdate() {
		return deptdate;
	}
	public void setDeptdate(String deptdate) {
		this.deptdate = deptdate;
	}
	public String getDepttime() {
		return depttime;
	}
	public void setDepttime(String depttime) {
		this.depttime = depttime;
	}
	public String getArrivaltime() {
		return arrivaltime;
	}
	public void setArrivaltime(String arrivaltime) {
		this.arrivaltime = arrivaltime;
	}
	public int getNoOfPassengers() {
		return noOfPassengers;
	}
	public void setNoOfPassengers(int noOfPassengers) {
		this.noOfPassengers = noOfPassengers;
	}
	public int getTotPrice() {
		return totPrice;
	}
	public void setTotPrice(int totPrice) {
		this.totPrice = totPrice;
	}

}
