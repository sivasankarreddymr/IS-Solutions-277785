package com.cts.atbs.service;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.cts.atbs.exception.AtbsException;
import com.cts.atbs.repo.AtbsRepository;
import com.cts.atbs.vo.AirLineTicket;
import com.cts.atbs.vo.AirLineTicketVo;
import com.cts.atbs.vo.BookTicket;
import com.cts.atbs.vo.Customer;
import com.cts.atbs.vo.Response;

public class AtbsServiceImplTest {
	
	@Mock
	AtbsRepository repo;
	
	@InjectMocks
	AtbsServiceImpl impl;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testRegister() throws AtbsException {
		when(repo.register(Mockito.any(Customer.class))).thenReturn(true);	
		boolean response=impl.register(new Customer());
		assertTrue(response);
		
	}

	@Test
	public void testLogin() throws AtbsException {
		when(repo.login(Mockito.any(Customer.class))).thenReturn(true);	
		boolean response=impl.login(new Customer());
		assertNotNull(response);
	}

	@Test
	public void testSearchFlights() throws AtbsException {
		when(repo.searchFlights(Mockito.any(AirLineTicketVo.class))).thenReturn(new ArrayList<AirLineTicket>());	
		List<AirLineTicketVo> list3= impl.searchFlights(new AirLineTicketVo());
		assertNotNull(list3);
	}

	@Test
	public void testBookFlight() throws AtbsException {
		when(repo.searchFlights(Mockito.any(AirLineTicketVo.class))).thenReturn(new ArrayList<AirLineTicket>());	
		List<AirLineTicketVo> list4= impl.searchFlights(new AirLineTicketVo());
		assertNotNull(list4);
	}

	@Test
	public void testCancelTicket() throws AtbsException {
		when(repo.cancelTicket(Mockito.any(BookTicket.class))).thenReturn(true);	
		boolean response=impl.cancelTicket(new BookTicket());
		assertNotNull(response);
	}

	@Test
	public void testGetFlights() throws AtbsException {
		when(repo.getFlights(Mockito.any(BookTicket.class))).thenReturn(new ArrayList<BookTicket>());	
		List<BookTicket> list= impl.getFlights(new BookTicket());
		assertNotNull(list);
	}

}
