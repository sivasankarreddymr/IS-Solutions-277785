package com.cts.atbs.controller;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.cts.atbs.exception.AtbsException;
import com.cts.atbs.service.AtbsService;
import com.cts.atbs.vo.AirLineTicketVo;
import com.cts.atbs.vo.BookTicket;
import com.cts.atbs.vo.Customer;
import com.cts.atbs.vo.Response;

public class AtbsControllerTest {
	
	@Mock
	AtbsService service;
	
	@InjectMocks
	AtbsController controller;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testRegister() throws AtbsException {		
		when(service.register(Mockito.any(Customer.class))).thenReturn(true);	
		Response response=controller.register(new Customer());
		assertNotNull(response);
	}

	@Test
	public void testLogin() throws AtbsException {
		when(service.login(Mockito.any(Customer.class))).thenReturn(true);	
		Response response=controller.login(new Customer());
		assertNotNull(response);
	}

	@Test
	public void testSearchFlights() throws AtbsException {
		when(service.searchFlights(Mockito.any(AirLineTicketVo.class))).thenReturn(new ArrayList<AirLineTicketVo>());	
		Response response=controller.searchFlights(new AirLineTicketVo());
		assertNotNull(response);
	}

	@Test
	public void testBookFlight() throws AtbsException {
		when(service.bookFlight(Mockito.any(BookTicket.class))).thenReturn(true);	
		Response response=controller.bookFlight(new BookTicket());
		assertNotNull(response);
	}

	@Test
	public void testGetFlights() throws AtbsException {
		when(service.getFlights(Mockito.any(BookTicket.class))).thenReturn(new ArrayList<BookTicket>());	
		Response response=controller.getFlights(new BookTicket());
		assertNotNull(response);
	}

	@Test
	public void testCancelTicket() throws AtbsException {
		when(service.cancelTicket(Mockito.any(BookTicket.class))).thenReturn(true);	
		Response response=controller.cancelTicket(new BookTicket());
		assertNotNull(response);
	}
}
