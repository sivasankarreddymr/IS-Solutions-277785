import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { User } from '../model/user';
import { LoginService } from '../login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  private regModel: User = new User('testuser@gmail.com', 'test123');
  constructor(private _loginService: LoginService, private _router: Router) { }

  ngOnInit() {
  }
  getLoginService(): LoginService {
    return this._loginService;
  }
  doLogin(loginForm: any) {
    if (loginForm != null) {
      if (loginForm.valid) {
        this._loginService.validateLogin(this.regModel).subscribe(res => {
          this._router.navigateByUrl('/tktbooking');
        }, err => {
          alert('exception occured while login');
        });
      } else {
        alert('please enter all the data');
      }
    }
  }

}
