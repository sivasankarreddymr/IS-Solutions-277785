import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import { LoginService } from '../login.service';

import { User } from '../model/user';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  private cfPWD: string;
  private regModel: User = new User('', '');
  isRegistered = false;
  constructor(private _loginService: LoginService, private _router: Router) { }

  ngOnInit() {
  }
  getLoginService(): LoginService {
    return this._loginService;
  }
  showLogin(): void {
    this._router.navigateByUrl('login');
  }
  registerCustomer(formObj: any): void {
    if (formObj != null) {
      if (formObj.valid) {
        if (this.regModel.password === this.cfPWD) {
          this.getLoginService().registerUser(this.regModel).subscribe(res => {
            this.isRegistered = true;
          }, err => {
            console.log(err);
          });
        }else {
          alert('Password and confirm passwords are not same');
        }
      } else {
        alert( 'Please enter all the data ');
      }
    }
  }
}
