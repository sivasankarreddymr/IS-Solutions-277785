import { LoginService } from '../login.service';
import { City, Category } from '../model/drop-downs';
import { Component, OnInit } from '@angular/core';
import { SearchForm} from '../model/searchform';
import { FlightDetails } from '../model/flightdetails';

@Component({
  selector: 'app-ticket-booking',
  templateUrl: './ticket-booking.component.html',
  styleUrls: ['./ticket-booking.component.css']
})
export class TicketBookingComponent implements OnInit {

  sourceFrom: any;
  to: string;
  category: string;
  deptDate: Date;
  deptTime: string;
  noOfPassengers: number;
  bookedFlightsArray: number[] = [];
  citiesList: City[];
  categoryList: Category[];
  hours: number[];
  minutes: string[] = [];
  selectedHour: number;
  selctedMin: number;
  noOfPassengersArray: number[] = [];
  availableFlights: FlightDetails[] = [];
  cancelFlightsArray: FlightDetails[] = [];
  constructor(private _loginService: LoginService) { }

  ngOnInit() {
    this.categoryList = this._loginService.getCategoreisData();
    this.citiesList = this._loginService.getCitiesList();
    this.hours = this._loginService.getHours();
    this.minutes.push('00', '30');
    this.noOfPassengersArray = this._loginService.getPassengersCount();
  }
  searchFlights(searchForm: any) {
    if ( searchForm != null ) {
      if (searchForm.valid) {
        const time = this.selectedHour + ':' + this.selctedMin;
        const date = new Date(this.deptDate);
        const formatDate = (date.getDate() + 1) + '/' + (date.getMonth() + 1) + '/' + date.getFullYear();
        const searchFormData = new SearchForm(this.sourceFrom, this.to, this.category, formatDate, time, this.noOfPassengers );
        this._loginService.searchFlights(searchFormData).subscribe(res => {
          if (res.flag && res.data.length > 0) {
           this.availableFlights = res.data;
          } else {
            this.availableFlights = [];
            alert('No Flights availble with selected criteria');
          }
        }, err => {
          alert('exception occured while login');
        });
      }
    }
  }
  selectFlights(): void {
    console.log('selected');
  }
  bookFlights(): void {
    console.log('booked');
  }
  cancelFlights(): void {
    console.log('cancel');
  }
  selectFlightsToCancel(): void {
    console.log('cancel');
  }
  onSelectOfSource(event: any) {
    this.sourceFrom = event;
  }
  onSelectOfCategory(event: any) {
    this.category = event;
  }
  onSelectOfPassengers(event: any) {
    this.noOfPassengers = event;
  }
  onSelectOfHours(event: any) {
   this.selectedHour = event;
  }
  onSelectOfminutes(event: any) {
    this.selctedMin = event;
  }
  onSelectOfTo(event: any) {
    this.to = event;
  }
}
