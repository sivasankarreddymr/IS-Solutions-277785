export class FlightDetails {
  constructor(
     public airline: string,
      public source: string,
       public destination: string,
       public category: string,
       public price: string,
       public deptdate: string,
      public depttime: string,
      public arrivaltime: string,
      public noOfPassengers: number,
      public totPrice: number
  ) { }
}
