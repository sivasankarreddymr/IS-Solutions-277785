export class SearchForm {
  constructor(
    public source: string,
    public destination: string,
    public category: string,
    public deptdate: string,
    public depttime: string,
    public noOfPassengers: number
  ) { }
}
