export class ResponseData {
    constructor(
        public flag: boolean,
        public data: any
    ) {}
}
