export class City {
  constructor(
     public cityCode: string,
    public cityName: string
  ) { }
}

export class Category {
  constructor(
    public catCode: string,
    public catName: string
  ) { }
}

