import { Category, City } from './model/drop-downs';
import { ResponseData } from './model/response-data';
import { SearchForm } from './model/searchform';
import { User } from './model/user';
import { Injectable } from '@angular/core';
import { ResolveData } from '@angular/router';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/Rx';
@Injectable()
export class LoginService {
  private _baseURL = 'http://localhost:9080/ATBS/';
  private _http: Http;
  private loggedInUser: string = null;
  constructor(http: Http) {
    this._http = http;
  }
  getBaseURL(): string {
    return this._baseURL;
  }
  validateLogin(userData: User): Observable<ResolveData> {
      const bodyString = JSON.stringify(userData);
      const loginUrl = this.getBaseURL() + 'validateLogin';
      const headers      = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
      const options       = new RequestOptions({ headers: headers }); // Create a request option
      return this._http.post(loginUrl, userData, options)
        .map((res: Response) => res.json()).catch((error: any) => Observable.throw(error.json().error || 'Server error'));
  }
  registerUser(userData: User): Observable<ResolveData> {
      const bodyString = JSON.stringify(userData);
      const loginUrl = this.getBaseURL() + 'register';
      const headers      = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
      const options       = new RequestOptions({ headers: headers }); // Create a request option
      return this._http.post(loginUrl, userData, options)
        .map((res: Response) => res.json()).catch((error: any) => Observable.throw(error.json().error || 'Server error'));
  }
  getCategoreisData(): Category[] {
    const dataArray: Category[] = [];
    dataArray.push(new Category('Business', 'Business'));
    dataArray.push(new Category('Economey', 'Economey'));
    dataArray.push(new Category('First', 'First'));
    return dataArray;
  }
  getCitiesList(): City[] {
    const citiesList: City[] = [];
    citiesList.push(new City('hyd', 'Hyderbad'));
    citiesList.push(new City('chn', 'Chennai'));
    return citiesList;
  }
  getHours(): number[] {
    const hours = [];
    for (let i = 0; i < 24; i++) {
      hours.push(i);
    }
    return hours;
  }
  getPassengersCount(): number[] {
    const passengersArray: number[] = [];
    passengersArray.push(1);
    passengersArray.push(2);
    passengersArray.push(3);
    passengersArray.push(4);
    passengersArray.push(5);
    return passengersArray;
  }
  searchFlights(searchData: SearchForm): Observable<ResolveData> {
      const loginUrl = this.getBaseURL() + 'searchFlights';
      const headers  = new Headers({ 'Content-Type': 'application/json' });
      const options  = new RequestOptions({ headers: headers });
      return this._http.post(loginUrl, searchData, options)
        .map((res: Response) => res.json()).catch((error: any) => Observable.throw(error.json().error || 'Server error'));
  }
}
