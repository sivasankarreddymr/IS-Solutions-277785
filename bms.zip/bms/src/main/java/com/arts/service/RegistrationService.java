package com.arts.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.arts.repository.UserRepository;
import com.arts.vo.User;

@Service
public class RegistrationService {
	@Autowired
	UserRepository userRepository;
	
	public User registerUser(User user) {
		
		return userRepository.create(user);
	}

	public User authenticateUser(User user) {
		
		return userRepository.authenticateUser(user);
	}
}
