package com.arts.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.arts.repository.FlightRepository;
import com.arts.repository.TicketRepository;
import com.arts.vo.Flight;
import com.arts.vo.Request;
import com.arts.vo.Ticket;
import com.arts.vo.User;

@Service
public class TicketReservationService {
	@Autowired
	TicketRepository ticketRepository;
	
	@Autowired
	FlightRepository flightRepository;
	
	public List<Flight> searchFlights(Request req) {
		
		return flightRepository.getFlightDetails(req);
	}
	
	
	public Ticket bookFlight(Request req) {
		Ticket ticket= new Ticket();
		ticket.setUser_id(req.getUser_id());
		ticket.setFlight_id(req.getFlight_id());
		ticket.setNo_of_seats(req.getNo_of_passengers());
		ticket = ticketRepository.bookTicket(ticket);
		flightRepository.update(req.getFlight_id(),req.getNo_of_passengers());
		return ticket;
	}
	
	public void cancelTicket(Request req) {
		ticketRepository.cancelTicket(req.getTicket_id());
	}
	
	
}
