package com.arts.vo;

import java.sql.Date;
import java.sql.Timestamp;

public class Flight {
	
	int flight_id;
	String flight_desc;
	String class_desc;
	int price;
	int  avaiable_seats;
	String from;
	String to;
	Date departure_date;
	Timestamp departure_time;
	Timestamp arrival_time;
	
	public int getFlight_id() {
		return flight_id;
	}
	public void setFlight_id(int flight_id) {
		this.flight_id = flight_id;
	}
	public String getFlight_desc() {
		return flight_desc;
	}
	public void setFlight_desc(String flight_desc) {
		this.flight_desc = flight_desc;
	}
	public String getClass_desc() {
		return class_desc;
	}
	public void setClass_desc(String class_desc) {
		this.class_desc = class_desc;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getAvaiable_seats() {
		return avaiable_seats;
	}
	public void setAvaiable_seats(int avaiable_seats) {
		this.avaiable_seats = avaiable_seats;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public Date getDeparture_date() {
		return departure_date;
	}
	public void setDeparture_date(Date departure_date) {
		this.departure_date = departure_date;
	}
	public Timestamp getDeparture_time() {
		return departure_time;
	}
	public void setDeparture_time(Timestamp departure_time) {
		this.departure_time = departure_time;
	}
	public Timestamp getArrival_time() {
		return arrival_time;
	}
	public void setArrival_time(Timestamp arrival_time) {
		this.arrival_time = arrival_time;
	}
	
	
}
