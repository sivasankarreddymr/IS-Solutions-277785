package com.arts.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.arts.vo.Flight;
import com.arts.vo.Request;
import com.arts.vo.Ticket;
import com.arts.vo.User;

@Repository
public class TicketRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	public Ticket bookTicket(Ticket ticket) {
		
		final String sql = "insert into ticket_details(user_id,flight_id,no_of_passengers,status) values(?,?,?,?)";
		 
		 KeyHolder holder = new GeneratedKeyHolder();
         jdbcTemplate.update(new PreparedStatementCreator() {
	             @Override
	             public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
	                 PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
	                 ps.setInt(1, ticket.getUser_id());
	                 ps.setInt(2, ticket.getFlight_id());
	                 ps.setInt(3, ticket.getNo_of_seats());
	                 ps.setString(3, "BOOKED");
	 		         return ps;
	             }
	         }, holder);
         int id = holder.getKey().intValue();
         ticket.setId(id);
		return ticket;
	}
	
	
	/*public Flight getBookedtickets(Request request) {
		return jdbcTemplate.queryForObject(
				"select * from flight_details where from=? and to=? and class=? "
				+ "and departure_date=? and departure_time=? and available_seats=?",
				new Object[] { 123 }, new FlightRowMapper());
	}*/
	
	public void cancelTicket(int id) {
		jdbcTemplate.update("update ticket_details set status ='CANCELED' where id="+id);
	}
	
}

class TicketRowMapper implements RowMapper<Ticket>
{

    @Override

    public Ticket mapRow(ResultSet rs, int rowNum) throws SQLException {
    	Ticket ticket = new Ticket();
        //user.setId(rs.getInt("id"));
        //user.setName(rs.getString("name"));
        //user.setEmail(rs.getString("email"));
        return ticket;
    }

}
