package com.arts.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.arts.vo.Flight;
import com.arts.vo.Request;
import com.arts.vo.User;

@Repository
public class FlightRepository {

	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	/*public User create(User user) {
		
		final String sql = "insert into user(username,password) values(?,?)";

		 KeyHolder holder = new GeneratedKeyHolder();
         jdbcTemplate.update(new PreparedStatementCreator() {
	             @Override
	             public PreparedStatement createPreparedStatement(Connection connection) throws SQLException {
	                 PreparedStatement ps = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
	                 ps.setString(1, user.getUsername());
	                 ps.setString(2, user.getPassword());
	 		         return ps;
	             }
	         }, holder);
         int newUserId = holder.getKey().intValue();
         user.setId(newUserId);
		return null;
		
	}*/
	
	public Flight findUserById(int id) {
        return jdbcTemplate.queryForObject(
            "select * from flight_details where id=?",
            new Object[]{id}, new FlightRowMapper());
    }
	
	
	public List<Flight> getFlightDetails(Request request) {		
		return jdbcTemplate.queryForList(
				"select * from flight_details where from=? and to=? and class=? "
				+ "and departure_date=? and available_seats=?",Flight.class,
				new Object[] { request.getFrom(),request.getTo(),request.getClassDesc(),request.getDepartureDate(),request.getNo_of_passengers()}, new FlightRowMapper());
	}
	
	public void update(int id,int numberOfSeats) {
		jdbcTemplate.update("update flight_details set available_seats ="+numberOfSeats+" where id="+id);
	}
	
}

class FlightRowMapper implements RowMapper<Flight>
{

    @Override
    public Flight mapRow(ResultSet rs, int rowNum) throws SQLException {
    	Flight flight = new Flight();
        //user.setId(rs.getInt("id"));
        //user.setName(rs.getString("name"));
        //user.setEmail(rs.getString("email"));
        return flight;
    }

}
