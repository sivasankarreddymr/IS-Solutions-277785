package com.arts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication

public class ARTSApplication {

	public static void main(String[] args) {
		SpringApplication.run(ARTSApplication.class, args);
	}
}
