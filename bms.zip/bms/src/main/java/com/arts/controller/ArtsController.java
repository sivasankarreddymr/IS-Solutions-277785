package com.arts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.arts.service.RegistrationService;
import com.arts.service.TicketReservationService;
import com.arts.vo.Flight;
import com.arts.vo.Request;
import com.arts.vo.Response;
import com.arts.vo.Ticket;
import com.arts.vo.User;

@RestController
public class ArtsController {
		
	@Autowired
	RegistrationService registrationService;
	
	@Autowired
	TicketReservationService ticketReservationService;
	
	@RequestMapping("/home")
	public ModelAndView home() {

		ModelAndView model = new ModelAndView("index");
		return model;
	}
	
	@RequestMapping(value = "/register", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public Response registerUser(@RequestBody User user) {
		Response response = new Response();
		try {
				registrationService.registerUser(user);
				response.setSuccess(true);
			
		} catch (Exception ex) {
			response.setSuccess(false);
			response.setData("Registration Failed. Please contact artssupportteam@cts.com. ");
		}
		return response;
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public Response login(@RequestBody User user) {
		Response response = new Response();
		try {
			user = registrationService.authenticateUser(user);
			if (user != null) {
				response.setSuccess(true);
				response.setData(user);
			} else {
				response.setSuccess(false);
				response.setData("Invalid Credentials");
			}

		} catch (Exception ex) {
			response.setSuccess(false);
			response.setData("Invalid Credentials");
		}
		return response;
	}

	@RequestMapping(value = "/searchFlights", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public Response searchFlights(@RequestBody Request request) {
		Response response = new Response();
		try {
			List<Flight> flightsList = ticketReservationService.searchFlights(request);
			response.setSuccess(true);
			response.setData(flightsList );
		} catch (Exception ex) {
			response.setSuccess(false);
			response.setData("Operation Failed");
		}
		return response;
	}
	
	
	@RequestMapping(value = "/bookFlight", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public Response bookFlight(@RequestBody Request request) {
		Response response = new Response();
		try {
			Ticket ticket = ticketReservationService.bookFlight(request);
			response.setSuccess(true);
			response.setData(ticket);

		} catch (Exception ex) {
			response.setSuccess(false);
			response.setData("OperationFailed");
		}
		return response;
	}

	@RequestMapping(value = "/cancelTicket", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public Response cancelTicket(@RequestBody Request request) {
		Response response = new Response();
		try {
			ticketReservationService.cancelTicket(request);
			response.setSuccess(true);			

		} catch (Exception ex) {
			response.setSuccess(false);
			response.setData("OperationFailed");
		}
		return response;
	}
}
