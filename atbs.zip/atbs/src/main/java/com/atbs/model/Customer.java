package com.atbs.model;

public class Customer {
	
	String from;
	String to;
	String departureDate;
	String time;
	String hours;
	String minutes;
	String noofpassengers;
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getDepartureDate() {
		return departureDate;
	}
	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getHours() {
		return hours;
	}
	public void setHours(String hours) {
		this.hours = hours;
	}
	public String getMinutes() {
		return minutes;
	}
	public void setMinutes(String minutes) {
		this.minutes = minutes;
	}
	public String getNoofpassengers() {
		return noofpassengers;
	}
	public void setNoofpassengers(String noofpassengers) {
		this.noofpassengers = noofpassengers;
	}
}
