package com.atbs.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;

@Entity
@Table(name="flightdetails")
public class DbCustomer {
	@Id
	@Column(name="flightid")
	int flightid;
	@Column(name="flightname")
	String flightname;
	@Column(name="from")
	String from;
	@Column(name="to")
	String to;
	@Column(name="travelclass")
	String travelclass;
	@Column(name="date")
	String date;
	@Column(name="arrtime")
	String arrtime;
	@Column(name="depttime")
	String depttime;
	@Column(name="availability")
	String availability;
	@Column(name="cost")
	double cost;
	public int getFlightid() {
		return flightid;
	}
	public void setFlightid(int flightid) {
		this.flightid = flightid;
	}
	public String getFlightname() {
		return flightname;
	}
	public void setFlightname(String flightname) {
		this.flightname = flightname;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getTravelclass() {
		return travelclass;
	}
	public void setTravelclass(String travelclass) {
		this.travelclass = travelclass;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getArrtime() {
		return arrtime;
	}
	public void setArrtime(String arrtime) {
		this.arrtime = arrtime;
	}
	public String getDepttime() {
		return depttime;
	}
	public void setDepttime(String depttime) {
		this.depttime = depttime;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}

}
