package com.atbs.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atbs.model.Customer;
import com.atbs.model.DbCustomer;
import com.atbs.model.DbUser;
import com.atbs.model.User;
import com.atbs.repository.FlightRepository;
import com.atbs.repository.UserRepository;

@Service
public class AirTicketService {
	
	//DbUser authenticateUser(User user);
	
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	FlightRepository flightRepository;
	
	public DbUser authenticateUser(User user) {
		DbUser validUser = userRepository.findByUsernameAndPassword(user.getUsername(), user.getPassword());		
		return validUser;	
		
	}
	
	public List<DbCustomer>  fetchFlightDetails(Customer customer) {
		List<DbCustomer> customerList = flightRepository.findAll();
		return customerList;
	}
	
	public void  register(User user) {
		List<User> userList = new ArrayList<User>();
		userList.add(user);
		//userRepository.save(userList);
		
	}


}
