package com.atbs.service;

import com.atbs.model.DbUser;
import com.atbs.model.User;
import com.atbs.repository.UserRepository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


public class AirTicketServiceImpl{
	
}
