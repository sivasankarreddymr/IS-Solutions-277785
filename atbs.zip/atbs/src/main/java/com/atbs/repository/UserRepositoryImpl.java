package com.atbs.repository;

import com.atbs.model.DbUser;

public class UserRepositoryImpl {
}
