package com.atbs.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.atbs.model.DbUser;
import com.atbs.model.Customer;
import com.atbs.model.DbCustomer;
import com.atbs.model.Response;
import com.atbs.model.User;
import com.atbs.repository.UserRepository;
import com.atbs.service.AirTicketService;



@RestController
public class AirTicketController {

	@Autowired
	AirTicketService airTicketService;
	
	@Autowired
	UserRepository userRepository;
	
	@RequestMapping("/home")
	public ModelAndView home() {

		ModelAndView model = new ModelAndView("index");
		return model;
	}
	
	

	@RequestMapping(value = "/login", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public Response login(@RequestBody User user) {
		Response response = new Response();
		try {
			DbUser validUser = airTicketService.authenticateUser(user);
			if (validUser != null) {
				response.setSuccess(true);
				response.setData(validUser);
			} else {
				response.setSuccess(false);
				response.setData("Invalid Credentials");
			}

		} catch (Exception ex) {
			response.setSuccess(false);
			response.setData("Invalid Credentials");
		}
		return response;
	}
	
	
	@RequestMapping(value = "/searchFlights", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public Response searchFlights(@RequestBody Customer customer) {
		Response response = new Response();
		try {
			List<DbCustomer> customerList = airTicketService.fetchFlightDetails(customer);
			response.setData(customerList.toArray());
			response.setSuccess(true);
		} catch (Exception ex) {
			response.setSuccess(false);
			response.setData("Invalid Credentials");
		}
		return response;
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST, consumes = "application/json")
	@ResponseBody
	public Response register(@RequestBody User user) {
		Response response = new Response();
		try {
			airTicketService.register(user);
			response.setSuccess(true);
		} catch (Exception ex) {
			response.setSuccess(false);
			response.setData("Invalid Credentials");
		}
		return response;
	}

}
