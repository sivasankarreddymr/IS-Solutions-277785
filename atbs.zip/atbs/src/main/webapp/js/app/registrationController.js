(function(){
	var app = angular.module("ARTSApp");
	app.controller("RegistrationController", ['$scope','$http','$state',function($scope,$http,$state) {
		
		$scope.customer ={};		
		$scope.errorsList = [];
		$scope.successmsg = "";		
		
		$scope.registration =function(){
		  $scope.errorsList = [];
	      $http.post('/atbs/register', $scope.customer).then(function(response){
	    	  if(response.data.success){
	    		  $state.go('login');
	    	  }else{
	    		  $scope.errorsList = response.data.data;
	    	  }
	      }); 
	   };
	  
	}]);
})();

