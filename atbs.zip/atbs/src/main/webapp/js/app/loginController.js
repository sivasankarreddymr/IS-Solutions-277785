(function(){
	var app = angular.module("ARTSApp");
	app.controller("LoginController", ['$scope','$http','appstore', '$state', '$rootScope',
	  function($scope, $http, appstore, $state, $rootScope) {
		$scope.user ={
			  username:'',
			  password:''
		};
		$rootScope.username = '';
		$scope.login =function(){
	      $http.post('/atbs/login', $scope.user).then(function(response){
	    	  if(response.data.success){
	    		  appstore.storeData('userDetails', response.data.data);
	    		  $state.go('managebookings');
	    	  }else{
	    		  $scope.errormsg = response.data.data;
	    	  }
	      }); 
	  };
	}]);
})();
