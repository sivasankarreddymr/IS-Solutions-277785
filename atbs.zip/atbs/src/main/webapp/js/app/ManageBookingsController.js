(function(){
	var app = angular.module("ARTSApp");
	app.controller("ManageBookingsController", ['$scope','$http', 'appstore',function($scope, $http, appstore) {
		
		jQuery('.datepicker').datepicker().on('changeDate',function(e){
			$scope.customer[e.currentTarget.getAttribute('ng-model')] = e.format('mm/dd/yyyy');
		});
		jQuery(document).off('.datepicker.data-api');
		var userdata = appstore.getData('userDetails');
		$scope.customer ={
			user_id: 123//userdata.id
		};
		$scope.details = [];
		
		$scope.cities = [
			{"code":"delhi","name":"Delhi"},
				{"code":"mumbai","name":"Mumbai"},
				{"code":"bangalore","name":"Bangalore"},
				{"code":"hyderabad","name":"Hyderabad"},
				{"code":"chennai","name":"Chennai"},
				{"code":"kolkata","name":"Kolkata"}
		];
		$scope.hoursList = [];
		for(var i = 0; i< 24; i++ ){
			$scope.hoursList.push(i);
		}
		$scope.mintsList = [];
		for(var i = 0; i< 60; i++ ){
			$scope.mintsList.push(i);
		}
		
		$scope.flightdetails = [];
		$scope.bookeddetails = [];
		
		$scope.searchFlights =function(){
		  console.log($scope.customer);
	      $http.post('/atbs/searchFlights', $scope.customer).then(function(response){
	    	  if(response.data.success)
	    		  $scope.flightdetails = response.data.data;
	      });
		  
		 /* 
		  var details = [{
			  id: 1,
			  transactionDate: '12/12/2017',
			  description: 'Abc xyz kjh',
			  debitCredit: 'Debit',
			  balance:'12000'
		  },{
			  id: 2,
			  transactionDate: '12/12/2017',
			  description: 'Abc xyz kjh',
			  debitCredit: 'Debit',
			  balance:'12000'
		  },{
			  id: 3,
			  transactionDate: '12/12/2017',
			  description: 'Abc xyz kjh',
			  debitCredit: 'Debit',
			  balance:'12000'
		  }];
		  */
		  //$scope.flightdetails = details;
		  $scope.bookeddetails = details;
		  
	    };
	    
	    $scope.booktktlist = [];
	    $scope.canceltktlist = [];
	    $scope.checkedFlight = function(index, type){
	    	var booktktlist = $scope[type == 'B' ? 'booktktlist' : 'canceltktlist'];
	    	if( booktktlist.indexOf(index) == -1){
	    		booktktlist.push(index);
	    	}else{
	    		var elIndex = '';
	    		angular.forEach(booktktlist, function(ind, rc){
	    			if(ind == index) elIndex = rc;
	    		});
	    		booktktlist.splice(elIndex, 1);
	    	}
	    	//console.log($scope.booktktlist);
	    	//console.log($scope.canceltktlist);
	    };
	    $scope.bookOrCancelTicket = function(type){
	    	var list = $scope[type == 'B' ? 'booktktlist' : 'canceltktlist'];
	    	cosnole.log(list);
	    	var url = type == 'B' ? 'bookFlight' : 'cancelTicket';
	    	$http.post('/ARTSApp/'+url, list).then(function(response){
	    		
		    });
	    };
	    
	}]);
})();